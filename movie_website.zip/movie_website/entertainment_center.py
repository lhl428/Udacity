import fresh_tomatoes
import media
zhanlang2 = media.Movie("zhanlang2","a story of a soldier","https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1511798734928&di=3103229e60a1e4e51a5451afae9088eb&imgtype=0&src=http%3A%2F%2Fwww.gxce.cn%2Fuploads%2Fallimg%2F170805%2F14-1FP5144512W5.jpg","http://v.youku.com/v_show/id_XMzA4OTA4OTQyMA==.html?spm=a2hmv.20009921.yk-slide-86993.5~5!3~5~5!2~A")
spiderman = media.Movie('Spider-Man:Homecoming', 'a boy bited by a spider',
                        'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1511800278255&di=e56ed1c934d0872a473b22441fb2b649&imgtype=0&src=http%3A%2F%2Fwww.visionunion.com%2Fadmin%2Fdata%2Ffile%2Fimg%2F20170711%2F20170711001411.jpg',
                        'http://v.youku.com/v_show/id_XMzEyMTcwNjAyMA==.html?spm=a2hmv.20009921.posterMovieGrid86981.5~5~5~1~3!2~A')

valerain = media.Movie('valerain','a story about polices in universe',
                       'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1511800440900&di=9a4860c2e2eaafd66418c16248d38a19&imgtype=0&src=http%3A%2F%2Fwww.th7.cn%2Fd%2Ffile%2Fp%2F2016%2F12%2F30%2F834b2aa8a5addd7b48fa1cf666850b28.jpg',
                       'http://v.youku.com/v_show/id_XMzE3NjAwNTIwOA==.html?spm=a2hmv.20009921.posterMovieGrid86981.5~5~5~1~3!2~A&from=s1.8-3-1.1')

gongshoudao = media.Movie('gongshoudao','a story about kungfu master',
                          'https://gss1.bdstatic.com/9vo3dSag_xI4khGkpoWK1HF6hhy/baike/w%3D268%3Bg%3D0/sign=0358f071ebfe9925cb0c6e560c9339e2/4d086e061d950a7b3b79a67001d162d9f2d3c932.jpg',
                          'http://v.youku.com/v_show/id_XMzE1MDc2ODYxNg==.html?spm=a2269.10614618.GSDVideo.1&f=51316394')

Shawshank = media.Movie('The Shawshank Redemption','A story about redemption',
                        'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1511800730980&di=d96525c1685c6400602024710c53e9d1&imgtype=0&src=http%3A%2F%2Fwww.jnnews.tv%2F_CMS_NEWS_IMG_%2Fwww2%2F2009-08%2F29%2Fcms_7cba49a6590e4dfbbffe3ff8572a6c45_0579_09_04_11.jpg',
                        'http://v.youku.com/v_show/id_XMjgwNDkwNzE2.html?from=y1.3-movie-grid-1095-9921.217752.4-1')

greatwall = media.Movie('greatwall','A story about a war',
                        'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1511800847567&di=da55fe9b60aeaa58f8e8432c51930489&imgtype=0&src=http%3A%2F%2Fimg0.utuku.china.com%2F400x0%2Fculture%2F20161230%2F7156cc8d-a96e-4998-8dec-1d0cf292603b.jpg',
                        'http://v.youku.com/v_show/id_XMjc4NTczOTM3Ng==.html?spm=a2hmv.20009921.posterMovieGrid86981.5~5~5~1~3!2~A&from=s1.8-3-1.1')


movies = [zhanlang2,spiderman,valerain,gongshoudao,Shawshank,greatwall]
fresh_tomatoes.open_movies_page(movies)
